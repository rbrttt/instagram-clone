<!-- footer.php -->

<!-- End of main content area -->
<script src="js/signup.js"></script>
</body>
</html>
